#ifndef Solara_Bridging_Header_h
#define Solara_Bridging_Header_h

#import <IOKit/IOKitLib.h>
#import <IOKit/graphics/IOGraphicsLib.h>

#endif
